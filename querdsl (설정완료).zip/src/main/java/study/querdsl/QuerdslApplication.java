package study.querdsl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuerdslApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuerdslApplication.class, args);
	}

}
